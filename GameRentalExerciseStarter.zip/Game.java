public class Game {
    private String title;
  
    public Game(String title){
      this.title = title;
    }

    // Constructors, getters, setters, etc.
}