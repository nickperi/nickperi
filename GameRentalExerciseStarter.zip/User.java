public abstract class User{
  protected String username;
  protected String password;

  protected User(String username, String password)
  {
   this.username = username;
   this.password = password;
  }
}